package com.loftysys.starbites.MVP;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VoucherResponse {
    private String status;
    private String data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }


}
